<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message>
        <source></source>
        <translation>새로 고침</translation>
    </message>
</context>
</TS>
