<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message>
        <source></source>
        <translation>Body</translation>
    </message>
</context>
<context>
    <name>ongmani.ct_picturetools</name>
    <message>
        <source></source>
        <translation>Batch Process</translation>
    </message>
</context>
<context>
    <name>wpscommon.mainwindow.commands</name>
    <message>
        <source></source>
        <translation>Screen Recording</translation>
    </message>
</context>
<context>
    <name>KxKsoTableStyleModel</name>
    <message>
        <source>Dark Style 2-Emphasize 3/Emphasize 4</source>
        <translation>Dark Style 2-Emphasize 3/Emphasize 4</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <translation>Dark Style 2-Emphasize 5/Emphasize 6</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Cell</comment>
        <translation>Size</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Color_Auto</comment>
        <translation>Auto</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Pap_Auto</comment>
        <translation>Auto</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Pap_SpaceAuto</comment>
        <translation>Auto</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>_TxFind_FinishSearchingDoc</comment>
        <translation>WPS Docs has finished searching the document.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>_TxFind_FinishSearchingDoc2</comment>
        <translation>WPS Docs has finished searching the document.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxCaption_PasteFormatedText</comment>
        <translation>Keep Source Formatting</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxHint_PasteFormatedText</comment>
        <translation>Keep Source Formatting</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxCaption_PasteText</comment>
        <translation>Unformatted Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxHint_PasteText</comment>
        <translation>Unformatted Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>OMathMat</comment>
        <translation>Left</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_ShadingColor</comment>
        <translation>Shading Color</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_TableShadingColor</comment>
        <translation>Shading Color</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sBracketNone</comment>
        <translation>(none)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sUnderlineNone</comment>
        <translation>(none)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sThisPointFor</comment>
        <translation>This point forward</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sThisPointForward</comment>
        <translation>This point forward</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Personal Version</comment>
        <translation>Switch UI</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Professional Version</comment>
        <translation>Switch UI</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sApplyWholeDocument</comment>
        <translation>Whole document</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sWhileDocument</comment>
        <translation>Whole document</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_Key_Overtype</comment>
        <translation>Typing</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_Key_Type</comment>
        <translation>Typing</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_Typing</comment>
        <translation>Typing</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>_TxFind_ReachEndOfHeaderFooterTextFrames</comment>
        <translation>Reached the end of the text box.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>_TxFind_ReachEndOfTextFrames</comment>
        <translation>Reached the end of the text box.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Menu</comment>
        <translation>Clarify Image</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateBkContent_HClassifyPeriod</comment>
        <translation>Classify Period</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateWidgetText_HClassifyPeriod</comment>
        <translation>Classify Period</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateBkContent_ECCSummary</comment>
        <translation>CC2</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateWidgetText_ECCSummary</comment>
        <translation>CC2</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>border</comment>
        <translation>St&amp;yle</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>shading</comment>
        <translation>St&amp;yle</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateMsgBox_BeforeSaveOkBtn</comment>
        <translation>Save</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateMsgBox_UnsavedOkBtn</comment>
        <translation>Save</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Chp_Not</comment>
        <translation>Not </translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Sep_Not</comment>
        <translation>Not </translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Bop_Top</comment>
        <translation>Top</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Pap_Top</comment>
        <translation>Top</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Sep_Top</comment>
        <translation>Top</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialPrintingVersionTemplateMsgBox_BeforeSaveText</comment>
        <translation>This template will be saved to &quot;%1&quot; under &quot;%2&quot;</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateMsgBox_BeforeSaveText</comment>
        <translation>This template will be saved to &quot;%1&quot; under &quot;%2&quot;</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxCaption_PasteOriginFormattedPopupMenu</comment>
        <translation>Keep Source Formating Paste</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxHint_PasteOriginFormattedPopupMenu</comment>
        <translation>Keep Source Formating Paste</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Bop_Bottom</comment>
        <translation>Bottom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Pap_Bottom</comment>
        <translation>Bottom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Sep_Bottom</comment>
        <translation>Bottom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateBkContent_HClassifyPeriod</comment>
        <translation>Classify Period</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateWidgetText_HClassifyPeriod</comment>
        <translation>Classify Period</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateBkContent_HOrderNum</comment>
        <translation>OrderNum</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateWidgetText_HOrderNum</comment>
        <translation>OrderNum</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateDrawText_EUndertakingDescription</comment>
        <translation>UndertakingDescription</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateWidgetText_EUndertakingDescription</comment>
        <translation>UndertakingDescription</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateBkContent_HIssueDate</comment>
        <translation>IssueDate</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateWidgetText_HIssueDate</comment>
        <translation>IssueDate</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Chp_SnapToGrid</comment>
        <translation>Snap to grid</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Pap_SnapToGrid</comment>
        <translation>Snap to grid</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sMarginsOrColumenSpacingLarge</comment>
        <translation>Settings you chose for the left and right margins,column spacing,or paragraph indents are too large for the page width in some sections.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateBkContent_HOrderNum</comment>
        <translation>Order Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateWidgetText_HOrderNum</comment>
        <translation>Order Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxBalloon_RevisionDeletedShortTip</comment>
        <translation>Delete</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_Delete</comment>
        <translation>Delete</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateBkContent_HIssueNum</comment>
        <translation>Issue Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateWidgetText_HIssueNum</comment>
        <translation>Issue Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Pap_None</comment>
        <translation>None</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>_TxNothing</comment>
        <translation>None</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateBkContent_HIssuer</comment>
        <translation>Issuer</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateWidgetText_HIssuer</comment>
        <translation>Issuer</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxCaption_NewBlankFile</comment>
        <translation>New Blank Document</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxCaption_TaskpaneNewBlankFile</comment>
        <translation>New Blank Document</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxTooltip_NewBlankFile</comment>
        <translation>New Blank Document</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxTooltip_TaskpaneNewBlankFile</comment>
        <translation>New Blank Document</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sClose</comment>
        <translation>Close</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sCloseDialog</comment>
        <translation>Close</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxCrossRefType_Table</comment>
        <translation>Table</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sTable</comment>
        <translation>Table</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>rainbow</comment>
        <translation>Wrap 
Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Table</comment>
        <translation>Gridlines</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sMore</comment>
        <translation>&amp;More</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sNotAdvancedMode</comment>
        <translation>&amp;More</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateBkContent_HSummaryNum</comment>
        <translation>Summary Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateWidgetText_HSummaryNum</comment>
        <translation>Summary Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Linux Version</comment>
        <translation>WPS Customer Service</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Windows Version</comment>
        <translation>WPS Customer Service</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Pap_Centered</comment>
        <translation>Centered</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxRevision_Pap_TabStopsCentered</comment>
        <translation>Centered</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sSelSection</comment>
        <translation>Selected sections</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sSelectedSections</comment>
        <translation>Selected sections</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sBrowseFind</comment>
        <translation>Find</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sFind</comment>
        <translation>Find</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxCaption_Paste</comment>
        <translation>Paste</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxEdit_PasteDefault</comment>
        <translation>Paste</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxHint_Paste</comment>
        <translation>Paste</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_Paste</comment>
        <translation>Paste</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sBorderDistanceFromText</comment>
        <translation>Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sText</comment>
        <translation>Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>OMathMatOrEqArr</comment>
        <translation>Bottom</translation>
    </message>
</context>
<context>
    <name>CWpsTableStyle</name>
    <message>
        <source>Dark Style 2-Emphasize 3/Emphasize 4</source>
        <translation>Dark Style 2-Emphasize 3/Emphasize 4</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <translation>Dark Style 2-Emphasize 5/Emphasize 6</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxDesc_DataSource_AllDataSource</comment>
        <translation>All Data Sources(%s) | %s |</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxDesc_DataSource_AllDataSourceEx</comment>
        <translation>All Data Sources(%s) | %s |</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateBkContent_HIssueUnitSummary</comment>
        <translation>Summary Mark</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialTemplateWidgetText_HIssueUnitSummary</comment>
        <translation>Summary Mark</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateBkContent_HIssueUnitSummary</comment>
        <translation>Summary Mark</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateWidgetText_HIssueUnitSummary</comment>
        <translation>Summary Mark</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxCaption_PasteMatchingFormat</comment>
        <translation>Match the Current Format</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxHint_PasteMatchingFormat</comment>
        <translation>Match the Current Format</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_InsPageNumber</comment>
        <translation>Page Numbers</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_InsertPageNumber</comment>
        <translation>Page Numbers</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>_TxMailMerge_CannotMergeWithThisDataSource</comment>
        <translation>WPS Docs could not merge the main document with the data source because the data records were empty or no data records matched your query options.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>_TxMailMerge_NoRecordExecute</comment>
        <translation>WPS Docs could not merge the main document with the data source because the data records were empty or no data records matched your query options.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sNotNumberRange</comment>
        <translation>The number must be between %d and %d.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sNumberOutofRange1</comment>
        <translation>The number must be between %d and %d.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sValidValue</comment>
        <translation>The number must be between %d and %d.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sAdvancedMode</comment>
        <translation>&amp;Less</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sLess</comment>
        <translation>&amp;Less</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Personal Version</comment>
        <translation>Switch UI</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Professional Version</comment>
        <translation>Switch UI</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Menu</comment>
        <translation>Clarify Image</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxCaption_NewFromDefaultTemplate</comment>
        <translation>From Default Template</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxCaption_TaskpaneNewFileFromDefaultTemplate</comment>
        <translation>New from Default Template</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxTooltip_NewFromDefaultTemplate</comment>
        <translation>New from Default Template</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxTooltip_TaskpaneNewFileFromDefaultTemplate</comment>
        <translation>New from Default Template</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateBkContent_EPrintQuantity</comment>
        <translation>Print Quantity</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateWidgetText_EPrintQuantity</comment>
        <translation>Print Quantity</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sApplyThisSection</comment>
        <translation>This section</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sThisSection</comment>
        <translation>This section</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateBkContent_EPrintDate</comment>
        <translation>Print Date</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxOfficialVersionTemplateWidgetText_EPrintDate</comment>
        <translation>Print Date</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_StylesAndFormatting_Caption</comment>
        <translation>Styles and Formatting</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_StylesAndFormatting_DisplayName</comment>
        <translation>Styles and Formatting</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sInvalidInt</comment>
        <translation>This is not a valid number.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sNotValidFontSize</comment>
        <translation>This is not a valid number.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxTooltip_TSCS</comment>
        <translation>Simplified/Traditional Chinese Translation</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>_TxTcscConvert</comment>
        <translation>Simplified/Traditional Chinese Translation</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sSelectText</comment>
        <translation>Selected text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sSelectedText</comment>
        <translation>Selected text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_FormatPainter</comment>
        <translation>Paste Format</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_PasteFormat</comment>
        <translation>Paste Format</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TXOMath_ButtonCancel</comment>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TXWps_SwitchButtonCancel</comment>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sErrorStart</comment>
        <translation>Start at must be between %d and %d for this format.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wps_sStartAtError</comment>
        <translation>Start at must be between %d and %d for this format.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_ChangeTextDirection</comment>
        <translation>Change Text Direction</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TxVersion_SetTextDirection</comment>
        <translation>Change Text Direction</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>SoundOrVedio</comment>
        <translation>From File</translation>
    </message>
</context>
</TS>
