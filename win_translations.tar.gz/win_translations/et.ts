<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message>
        <source></source>
        <translation>Font Color</translation>
    </message>
</context>
<context>
    <name>KxKsoTableStyleModel</name>
    <message>
        <source>Dark Style 2-Emphasize 3/Emphasize 4</source>
        <translation>Dark Style 2-Emphasize 3/Emphasize 4</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <translation>Dark Style 2-Emphasize 5/Emphasize 6</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_259</comment>
        <translation>is the value for which you want the distribution.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_266</comment>
        <translation>is the value for which you want the distribution.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_Undo_Paste</comment>
        <translation>Paste</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_Undo_PasteName</comment>
        <translation>Paste</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SOLVER_ITERATIONS</comment>
        <translation>Iterations</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SOLVER_ITERATIONS_TIMES</comment>
        <translation>Iterations</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PivotTable_Consolidate_RowField</comment>
        <translation>Row</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SortParam_KeyName_Row</comment>
        <translation>Row</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_212</comment>
        <translation>is a logical value: the constant b is calculated normally if Const = TRUE or omitted; b is set equal to 1 if Const = FALSE.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_220</comment>
        <translation>is a logical value: the constant b is calculated normally if Const = TRUE or omitted; b is set equal to 1 if Const = FALSE.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_323</comment>
        <translation>is the position of the character in Old_text that you want to replace with New_text.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_327</comment>
        <translation>is the position of the character in Old_text that you want to replace with New_text.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_CHECKSPELLING_FROMCENTERFOOTER</comment>
        <translation>Center section </translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_CHECKSPELLING_FROMCENTERHEADER</comment>
        <translation>Center section </translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Menu</comment>
        <translation>AI Matting</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_421</comment>
        <translation>If_not_found</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_432</comment>
        <translation>If_not_found</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_028</comment>
        <translation>Instance_num</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_430</comment>
        <translation>Instance_num</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_024</comment>
        <translation>is an optional upper bound to the interval of x. If omitted, B = 1.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_027</comment>
        <translation>is an optional upper bound to the interval of x. If omitted, B = 1.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOTTABLE_ListFormula_Item</comment>
        <translation>Item</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_Sharepoint_FSObjType_Item</comment>
        <translation>Item</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_081</comment>
        <translation>is the number of periods over which the asset is being depreciated (sometimes called the useful life of the asset).</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_091</comment>
        <translation>is the number of periods over which the asset is being depreciated (sometimes called the useful life of the asset).</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_363</comment>
        <translation>is the number of periods over which the asset is being depreciated (sometimes called the useful life of the asset).</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>ChartLegend</comment>
        <translation>Left</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>FillLeft</comment>
        <translation>Left</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>OMath</comment>
        <translation>Left</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDBE_FLTR_ORDER_DESC</comment>
        <translation>Descending</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDBE_STR_ORDR_DESC</comment>
        <translation>Descending</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_074</comment>
        <translation>is either the label of the column in double quotation marks or a number that represents the column&apos;s position in the list.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_085</comment>
        <translation>is either the label of the column in double quotation marks or a number that represents the column&apos;s position in the list.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_096</comment>
        <translation>is either the label of the column in double quotation marks or a number that represents the column&apos;s position in the list.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_099</comment>
        <translation>is either the label of the column in double quotation marks or a number that represents the column&apos;s position in the list.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_100</comment>
        <translation>is either the label of the column in double quotation marks or a number that represents the column&apos;s position in the list.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_391</comment>
        <translation></translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_Pr1</comment>
        <translation>Pr</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_384</comment>
        <translation>is the condition or criteria in the form of a number, expression, or text that defines which cells will be used to find the average.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_AVERAGEIF_AVERAGEIFS_Criteria</comment>
        <translation>is the condition or criteria in the form of a number, expression, or text that defines which cells will be used to find the average.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_MAXIFS_Criteria</comment>
        <translation>is the condition or criteria in the form of a number, expression, or text that defines which cells will be included when determining the maximum value.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_MINIFS_Criteria</comment>
        <translation>is the condition or criteria in the form of a number, expression, or text that defines which cells will be included when determining the minimum value.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_SUMIFS_Criteria</comment>
        <translation>is the condition or criteria in the form of a number, expression, or text that defines which cells will be added.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERR_BLOCKED_InvalidUrl</comment>
        <translation>Invalid URL</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERR_VALUE_InvalidUrl</comment>
        <translation>Invalid URL</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_108</comment>
        <translation>Start_period</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_212</comment>
        <translation>Start_period</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_144</comment>
        <translation>N</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_160</comment>
        <translation>N</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_112</comment>
        <translation>X</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_133</comment>
        <translation>X</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_134</comment>
        <translation>Lambda</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_143</comment>
        <translation>X</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_632</comment>
        <translation>Searches the text for a delimiter match. By default, a case-sensitive match is done.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_637</comment>
        <translation>Searches the text for a delimiter match. By default, a case-sensitive match is done.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_069</comment>
        <translation>Start_date</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_384</comment>
        <translation>Start_date</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_260</comment>
        <translation>is the arithmetic mean of the distribution.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_264</comment>
        <translation>is the arithmetic mean of the distribution.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_370</comment>
        <translation>is the arithmetic mean of the distribution.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_157</comment>
        <translation>is a logical value: the constant b is calculated normally if Const = TRUE; b is set equal to 1 if Const = FALSE or omitted.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_159</comment>
        <translation>is a logical value: the constant b is calculated normally if Const = TRUE; b is set equal to 1 if Const = FALSE or omitted.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_031</comment>
        <translation>is a logical value: for the cumulative distribution function, use TRUE; for the probability mass function, use FALSE.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_032</comment>
        <translation>is the value you want to round.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_444</comment>
        <translation>is the security&apos;s issue date, expressed as a serial date number.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_468</comment>
        <translation>is the security&apos;s issue date, expressed as a serial date number.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_045</comment>
        <translation>Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_047</comment>
        <translation>Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_048</comment>
        <translation>Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_139</comment>
        <translation>Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_161</comment>
        <translation>Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_173</comment>
        <translation>Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_ISEVEN_Number</comment>
        <translation>Number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_261</comment>
        <translation>Formula_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_321</comment>
        <translation>Formula_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>FuncCatName12</comment>
        <translation>User Defined</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>FuncCatName18</comment>
        <translation>User Defined</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOT_VALUES</comment>
        <translation>Values</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PivotTable_Values</comment>
        <translation>Values</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_104</comment>
        <translation>Values</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_238</comment>
        <translation>Values</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Personal Version</comment>
        <translation>Switch UI</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Professional Version</comment>
        <translation>Switch UI</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDataForm_ArraryFormula</comment>
        <translation>You cannot change part of an array.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDataFrom_ArraryFormula</comment>
        <translation>You cannot change part of an array.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_122</comment>
        <translation>Alpha</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_131</comment>
        <translation>Alpha</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_156</comment>
        <translation>Alpha</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_164</comment>
        <translation>Alpha</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_248</comment>
        <translation>Shortcut_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_308</comment>
        <translation>Shortcut_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_DESC_APP_NAME</comment>
        <translation>WPS Sheets</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_191</comment>
        <translation>is the future value, or a cash balance you want to attain after the last payment is made. If omitted, zero is used.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_271</comment>
        <translation>is the future value, or a cash balance you want to attain after the last payment is made. If omitted, zero is used. The default is 0</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_294</comment>
        <translation>is the future value, or a cash balance you want to attain after the last payment is made. If omitted, zero is used.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_302</comment>
        <translation>is the future value, or a cash balance you want to attain after the last payment is made. If omitted, zero is used.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_Regular1</comment>
        <translation>Regular</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_Regular2</comment>
        <translation>Regular</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SETDLGCAPTION_EDIT</comment>
        <translation>Format Cells</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SETEDITCAPTION</comment>
        <translation>Format Cells</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_067</comment>
        <translation>Sheet_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_289</comment>
        <translation>Sheet_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERRDESCEX_Spill_RangeIsNotBlank</comment>
        <translation>The cells where data is spilled are not blank.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERRDESC_Spill_RangeIsNotBlank</comment>
        <translation>The cells where data is spilled are not blank.</translation>
    </message>
</context>
<context>
    <name>CEtTableStyle</name>
    <message>
        <source>Dark Style 2-Emphasize 3/Emphasize 4</source>
        <translation>Dark Style 2-Emphasize 3/Emphasize 4</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <translation>Dark Style 2-Emphasize 5/Emphasize 6</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>GAMMALN_GRAMMER</comment>
        <translation>GAMMALN(x)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>GAMMALN_SYNTAX</comment>
        <translation>GAMMALN(x)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOTTABLE_CANNOT_HIDE_SELECTION</comment>
        <translation>You cannot hide this selection.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOTTABLE_CannotHideSelected</comment>
        <translation>You cannot hide this selection.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ssDesc_ET_</comment>
        <translation>WPS Spreadsheets Files(*.et)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ssDesc_ET_Save</comment>
        <translation>WPS Spreadsheets Files(*.et)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_080</comment>
        <translation>is the salvage value at the end of the life of the asset.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_090</comment>
        <translation>is the salvage value at the end of the life of the asset.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_392</comment>
        <translation>is the salvage value at the end of the life of the asset.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_Salvage</comment>
        <translation>is the salvage value at the end of the life of the asset.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_206</comment>
        <translation>is the text string containing the characters you want to extract.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_332</comment>
        <translation>is the text string containing the characters you want to extract.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERRDESCEX_Spill_TooComplex</comment>
        <translation>The formula is too complex to spill the result into neighboring cells.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERRDESC_Spill_TooComplex</comment>
        <translation>The formula is too complex to spill the result into neighboring cells.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>shortHint</comment>
        <translation>Note</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Menu</comment>
        <translation>AI Matting</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERRDESCEX_Spill_RangeIsInTable</comment>
        <translation>Unable to spill data into neighboring cells within the table.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERRDESC_Spill_RangeIsInTable</comment>
        <translation>Unable to spill data into neighboring cells within the table.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>OMath</comment>
        <translation>Right</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_AutoInput_NumberFrom1MonTo7Sun</comment>
        <translation>Number From 1(Mon) To 7(Sun)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_AutoInput_NumberFromMonToSun</comment>
        <translation>Number From 1(Mon) To 7(Sun)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ssDesc_AllET_</comment>
        <translation>WPS Spreadsheets Files(*.et; *.ett)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ssDesc_ET2003_</comment>
        <translation>WPS Spreadsheets Files(*.et; *.ett)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERRDESC_CalculateUnfinished</comment>
        <translation>Calculation incomplete</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERR_CalculateUnfinished</comment>
        <translation>Calculation incomplete</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>NewName</comment>
        <translation>Define Name</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_NEWBLANKFILECAPTION</comment>
        <translation>New File</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_TPNEWBLANKFILECAPTION</comment>
        <translation>New File</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_295</comment>
        <translation>is a logical value: payment at the beginning of the period = 1; payment at the end of the period = 0 or omitted.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_321</comment>
        <translation>is a logical value: payment at the beginning of the period = 1; payment at the end of the period = 0 or omitted.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_DESC_CopyPaste_MultiRange_ET</comment>
        <translation>This command cannot be used on multiple selections.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_Noncontinue_Selected_Sheets_Cannot_Insert_Sheet</comment>
        <translation>This command cannot be used on multiple selections.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_154</comment>
        <translation>is the set of y-values you already know in the relationship y=b*m^x, an array or range of positive numbers.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_218</comment>
        <translation>is the set of y-values you already know in the relationship y=b*m^x, an array or range of positive numbers.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_255</comment>
        <translation>is number in the date-time code used by WPS Spreadsheets.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_445</comment>
        <translation>is number in the date-time code used by WPS Spreadsheets.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOTTABLE_GETPIVOTDATA_SUBTOTAL_VARP</comment>
        <translation>Varp</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOT_SUBTOTAL_VARP</comment>
        <translation>Varp</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SUBTOTAL_VARP</comment>
        <translation>Varp</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERROR_MERGECELLINSORT</comment>
        <translation>The merged cells cannot be sorted.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_MergedCell_InRange</comment>
        <translation>The merged cells cannot be sorted.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>NORMDOTSDOTDIST_DESCRIPTION</comment>
        <translation>Returns the standard normal distribution (has a mean of zero and a standard deviation of one).</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>NORMSDIST_DESCRIPTION</comment>
        <translation>Returns the standard normal distribution (has a mean of zero and a standard deviation of one).</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_065</comment>
        <translation>Serial_number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_066</comment>
        <translation>Serial_number</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_105</comment>
        <translation>is the value to round.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_275</comment>
        <translation>is the value to round.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_462</comment>
        <translation>is the value to round.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_190</comment>
        <translation>lump sum amount that series of future payments is right now.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_202</comment>
        <translation>lump sum amount that series of future payments is right now.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_102</comment>
        <translation>Type</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_147</comment>
        <translation>Type</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_125</comment>
        <translation>Number_s</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_154</comment>
        <translation>Number_s</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_140</comment>
        <translation>is the total number of payment periods.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_309</comment>
        <translation>is the total number of payment periods.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_058</comment>
        <translation>Reference</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_229</comment>
        <translation>Reference</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_231</comment>
        <translation>Reference</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_237</comment>
        <translation>Reference</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_313</comment>
        <translation>Reference</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_317</comment>
        <translation>Reference</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_322</comment>
        <translation>Reference</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_326</comment>
        <translation>Reference</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_024</comment>
        <translation>Height</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_Image_Height</comment>
        <translation>Height</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SizeTip_Row</comment>
        <translation>Height</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PageNumberString1</comment>
        <translation>Page %d</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PageNumberString1_</comment>
        <translation>Page %d</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_BoldItalic</comment>
        <translation>Bold Italic</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_BoldItalic2</comment>
        <translation>Bold Italic</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_BoldItalic3</comment>
        <translation>Bold Italic</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_BoldItalic_</comment>
        <translation>Bold Italic</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sClose</comment>
        <translation>Close</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sCloseDialog</comment>
        <translation>Close</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOTTABLE_GETPIVOTDATA_SUBTOTAL_COUNTNUMS</comment>
        <translation>Numerical Count</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SUBTOTAL_COUNTNUMS</comment>
        <translation>Numerical Count</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_034</comment>
        <translation>is a text value that specifies what type of cell information you want.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_035</comment>
        <translation>is a text value that specifies what type of cell information you want.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_479</comment>
        <translation>is a text value that specifies what type of cell information you want.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_227</comment>
        <translation>Name_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_235</comment>
        <translation>Name_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_239</comment>
        <translation>Name_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_254</comment>
        <translation>Name_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_305</comment>
        <translation>Name_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_032</comment>
        <translation>Logical</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_034</comment>
        <translation>Logical</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_035</comment>
        <translation>Logical</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_283</comment>
        <translation>Logical</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_239</comment>
        <translation>is the position of the first character you want to extract. The first character in Text is 1.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_242</comment>
        <translation>is the position of the first character you want to extract. The first character in Text is 1.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_036</comment>
        <translation>Lookup_array</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_422</comment>
        <translation>Lookup_array</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_Italic1</comment>
        <translation>Italic</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_Italic2</comment>
        <translation>Italic</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_Italic3</comment>
        <translation>Italic</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_AutoInput_Year</comment>
        <translation>Year</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_087</comment>
        <translation>Year</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_COL_WIDTH</comment>
        <translation>Width</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_088</comment>
        <translation>Width</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_Image_Width</comment>
        <translation>Width</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SizeTip_Col</comment>
        <translation>Width</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_BookUnProtectDlgTitle</comment>
        <translation>Unprotect Book</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_BookUnProtectHint</comment>
        <translation>Unprotect Book</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_073</comment>
        <translation>is the range of cells that makes up the list or database. A database is a list of related data.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_084</comment>
        <translation>is the range of cells that makes up the list or database. A database is a list of related data.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_087</comment>
        <translation>is the range of cells that makes up the list or database. A database is a list of related data.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_088</comment>
        <translation>is the range of cells that makes up the list or database. A database is a list of related data.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_095</comment>
        <translation>is the range of cells that makes up the list or database. A database is a list of related data.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_098</comment>
        <translation>is the range of cells that makes up the list or database. A database is a list of related data.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_Field</comment>
        <translation>is the column to count. It can be either the label of the column in double quotation marks or a number that represents the column&apos;s position in the list.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_177</comment>
        <translation>selects the column in Array or Reference from which to return a value. If omitted, Row_num is required.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_180</comment>
        <translation>selects the column in Array or Reference from which to return a value. If omitted, Row_num is required.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_AutoInput_Hour</comment>
        <translation>Hour</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_026</comment>
        <translation>Hour</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_296</comment>
        <translation>Selection</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_341</comment>
        <translation>Selection</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ZoomBox_Selection</comment>
        <translation>Selection</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_389</comment>
        <translation>is the second range or array of numbers and be a number or name, array, or reference that contains numbers.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_393</comment>
        <translation>is the second range or array of numbers and be a number or name, array, or reference that contains numbers.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>FREAD_SYNTAX</comment>
        <translation>FREAD(file_num, num_chars)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>FWRITE_SYNTAX</comment>
        <translation>FREAD(file_num, num_chars)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_241</comment>
        <translation>Module_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_347</comment>
        <translation>Module_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_243</comment>
        <translation>Type_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_349</comment>
        <translation>Type_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_Info_Type_Text</comment>
        <translation>Type_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_197</comment>
        <translation>Info_type</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_240</comment>
        <translation>Info_type</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_359</comment>
        <translation>is the angle in radians for which you want the sine. Degrees *PI()/180 = radians.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_395</comment>
        <translation>is the angle in radians for which you want the sine. Degrees *PI()/180 = radians.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_UNDEF_FINDFMT</comment>
        <translation>No Format Set</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_UNDEF_FMT</comment>
        <translation>No Format Set</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_Undo_DeletePageBreak</comment>
        <translation>Remove Page Break</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_Undo_RemovePageBreak</comment>
        <translation>Remove Page Break</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sErrorBadRange</comment>
        <translation>The number must be between 1 and 32767. Try again by entering a number in this range.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sNumberOutof1and32767</comment>
        <translation>The number must be between 1 and 32767. Try again by entering a number in this range.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sBadValue</comment>
        <translation>Your entry cannot be used. An integer or decimal number may be required.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sEmptyentry</comment>
        <translation>Your entry cannot be used. An integer or decimal number may be required.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sNeedIntegerOrDecimal</comment>
        <translation>Your entry cannot be used. An integer or decimal number may be required.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sRequireNumber</comment>
        <translation>Your entry cannot be used. An integer or decimal number may be required.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOT_SUBTOTAL_COUNTN_SEED</comment>
        <translation>Count of %s</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOT_SUBTOTAL_COUNT_SEED</comment>
        <translation>Count of %s</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_AutoInput_NumberFrom1SunTo7Sat</comment>
        <translation>Number From 1(Sun) To 7(Sat)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_AutoInput_NumberFromSunToSat</comment>
        <translation>Number From 1(Sun) To 7(Sat)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_DESC_CHART_NAME</comment>
        <translation>Chart</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_OnSetHostNames_2</comment>
        <translation>Chart</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDBE_FLTR_ORDER_ASC</comment>
        <translation>Ascending</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDBE_STR_ORDR_ASC</comment>
        <translation>Ascending</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_176</comment>
        <translation>selects the row in Array or Reference from which to return a value. If omitted, Column_num is required.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_179</comment>
        <translation>selects the row in Array or Reference from which to return a value. If omitted, Column_num is required.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_New_Sheet_Name</comment>
        <translation>Sheet</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ShareWorkbook_ListChanges_Sheet</comment>
        <translation>Sheet</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_242</comment>
        <translation>Procedure</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_348</comment>
        <translation>Procedure</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_428</comment>
        <translation>Pad_with</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_433</comment>
        <translation>Pad_with</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_196</comment>
        <translation>is the value you want to test. Values can be a cell, a formula, or a name that refers to a cell, formula, or value.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_197</comment>
        <translation>is the value you want to test. Values can be a cell, a formula, or a name that refers to a cell, formula, or value.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>CEILING_MATH_REMARK</comment>
        <translation>Rounds a number up, to the nearest integer or to the nearest multiple of significance.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>CEILING_REMARK</comment>
        <translation>Rounds a number up, to the nearest multiple of significance.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_385</comment>
        <translation>is the actual cells to sum.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_624</comment>
        <translation>is the actual cells to sum.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Linux Version</comment>
        <translation>WPS Customer Service</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Windows Version</comment>
        <translation>WPS Customer Service</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ssDesc_Xls_</comment>
        <translation>Microsoft Excel 97-2003 Workbook(*.xls)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ssDesc_Xls_Save</comment>
        <translation>Microsoft Excel 97-2003 Workbook(*.xls)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_247</comment>
        <translation>Category</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_310</comment>
        <translation>Category</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERRDESCEX_Spill_RangeHasMergedCell</comment>
        <translation>Unable to spill data into merged cells.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERRDESC_Spill_RangeHasMergedCell</comment>
        <translation>Unable to spill data into merged cells.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOT_GRANDTOTAL_PivotChart</comment>
        <translation>Grand Total</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOT_LABEL_GRAND</comment>
        <translation>Grand Total</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOT_LABEL_GRAND2</comment>
        <translation>Grand Total</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SUBTOTAL_SUM2</comment>
        <translation>Grand Total</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_326</comment>
        <translation>is the text in which you want to replace.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_329</comment>
        <translation>is the text in which you want to replace.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_155</comment>
        <translation>is an optional set of x-values that you may already know in the relationship y=b*m^x, an array or range the same size as Known_y&apos;s.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_219</comment>
        <translation>is an optional set of x-values that you may already know in the relationship y=b*m^x.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDBE_FIELD</comment>
        <translation>Field names</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDBE_STR_FIELD</comment>
        <translation>Field names</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_004</comment>
        <translation>Array</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_007</comment>
        <translation>Array</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaType_410</comment>
        <translation>Array</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PageNumberString2</comment>
        <translation>Page %d of %d</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PageNumberString2_</comment>
        <translation>Page %d of %d</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERROR_Array_PartChange</comment>
        <translation>Part of an array cannot be changed.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_TextToColumns_Tip3</comment>
        <translation>Part of an array cannot be changed.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>NORMDIST_DESCRIPTION</comment>
        <translation>Returns the normal distribution for the specified mean and standard deviation.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>NORMDOTDIST_DESCRIPTION</comment>
        <translation>Returns the normal distribution for the specified mean and standard deviation.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_Bold1</comment>
        <translation>Bold</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_Bold2</comment>
        <translation>Bold</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_Bold3</comment>
        <translation>Bold</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_FontName_Bold5</comment>
        <translation>Bold</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Fill</comment>
        <translation>Series</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SheetUnProtect</comment>
        <translation>Unprotect 
Sheet</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SheetUnProtectHint</comment>
        <translation>Unprotect 
Sheet</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_189</comment>
        <translation>number of payment periods in an investment.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_201</comment>
        <translation>number of payment periods in an investment.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_063</comment>
        <translation>Rows</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_403</comment>
        <translation>Rows</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_246</comment>
        <translation>Macro_type</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_307</comment>
        <translation>Macro_type</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>STR_STYLE_20P_ACCENT_2</comment>
        <translation>20% - Accent2</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>STR_STYLE_40P_ACCENT_4</comment>
        <translation>40% - Accent4</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_Undo_SetPrintArea</comment>
        <translation>Set Print Area</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_Undo_SetPrintAreas</comment>
        <translation>Set Print Area</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_350</comment>
        <translation>is the name of the server where the add-in should be run. Enclose the name in quotation marks. If the add-in is run locally, use an empty string.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_547</comment>
        <translation>is the name of the server where the add-in should be run. Enclose the name in quotation marks. If the add-in is run locally, use an empty string.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_099</comment>
        <translation>Rate</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_101</comment>
        <translation>Rate</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_201</comment>
        <translation>Rate</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_205</comment>
        <translation>is the position (from the largest) in the array or cell range of the value to return</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_LCM_Number</comment>
        <translation>number1,number2…are 1 to 255 values for which you want the least common multiple.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOTTABLE_GETPIVOTDATA_SUBTOTAL_STDEV</comment>
        <translation>StdDev</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOT_SUBTOTAL_STDDEV</comment>
        <translation>StdDev</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SUBTOTAL_STDEV</comment>
        <translation>StdDev</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERRDESCEX_Spill_RangeIsTooBig</comment>
        <translation>Unable to extend data beyond the edge of the worksheet.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERRORCHECK_ERRDESC_Spill_RangeIsTooBig</comment>
        <translation>Unable to extend data beyond the edge of the worksheet.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_MERGESHEET_REPORT_State</comment>
        <translation>Status</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SOLVER_STATUS</comment>
        <translation>Status</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_467</comment>
        <translation>is an optional array of one or more serial date numbers to exclude from the working calendar, such as state and federal holidays and floating holidays.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_577</comment>
        <translation>is an optional array of one or more serial date numbers to exclude from the working calendar, such as state and federal holidays and floating holidays.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_023</comment>
        <translation>is a parameter to the distribution and must be greater than 0.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_026</comment>
        <translation>is a parameter to the distribution and must be greater than 0.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_NEWFILEFROMTEMPLATECAPTION</comment>
        <translation>From Default Template</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_TPNEWFILEFROMTEMPLATECAPTION</comment>
        <translation>From Default Template</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>PERMUT_DESCRIPTION</comment>
        <translation>Returns the number of permutations for a given number of objects that can be selected from the total objects.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>PERMUT_REMARK</comment>
        <translation>Returns the number of permutations for a given number of objects that can be selected from the total objects.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_437</comment>
        <translation>Number of columns</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_438</comment>
        <translation>Number of columns</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_CanNotEdit4CoopMode</comment>
        <translation>You cannot modify the read-only cells on protected worksheet for cooperation mode.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_CanNotEdit_TOAST</comment>
        <translation>You cannot modify the read-only cells on protected worksheet for cooperation mode.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ERROR_INVALID_REFERENCE</comment>
        <translation>Reference is invalid.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_Hyperlink_Cannot_OpenRef</comment>
        <translation>Reference is invalid.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_208</comment>
        <translation>is the text from which you want to exact part of character strings.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_241</comment>
        <translation>is the text from which you want to exact part of character strings.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_452</comment>
        <translation>is the hexadecimal number you want to convert.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_465</comment>
        <translation>is the hexadecimal number you want to convert.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOTTABLE_GETPIVOTDATA_SUBTOTAL_AVERAGE</comment>
        <translation>Average</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOT_SUBTOTAL_AVERAGE</comment>
        <translation>Average</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SUBTOTAL_AVERAGE</comment>
        <translation>Average</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sDlgCustomAutoFilter_DoesNotEqual</comment>
        <translation>not equal to</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sNotEqual</comment>
        <translation>not equal to</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>STR_STYLE_20P_ACCENT_3</comment>
        <translation>20% - Accent3</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>STR_STYLE_40P_ACCENT_5</comment>
        <translation>40% - Accent5</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_188</comment>
        <translation>is the period for which you want to find the interest and must be in the range 1 to Nper.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_200</comment>
        <translation>period for which you want to find interest.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_292</comment>
        <translation>is the total number of payment periods for the loan or investment.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_318</comment>
        <translation>is the total number of payment periods for the loan or investment.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_079</comment>
        <translation>Value</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_082</comment>
        <translation>Value</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_083</comment>
        <translation>Value</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_116</comment>
        <translation>Value</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_226</comment>
        <translation>Value</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_236</comment>
        <translation>Value</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_376</comment>
        <translation>Value</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_AVERAGEA_Value</comment>
        <translation>Value</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_MINA_Value</comment>
        <translation>Value</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_AutoInput_Integer</comment>
        <translation>Integer</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_409</comment>
        <translation>Integer</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_043</comment>
        <translation>Num_chars</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_259</comment>
        <translation>Num_chars</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_145</comment>
        <translation>is a parameter to distribution, a positive number.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_149</comment>
        <translation>is a parameter to distribution, a positive number.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>PERMUT_GRAMMER</comment>
        <translation>PERMUT(number,number_chosen)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>PERMUT_SYNTAX</comment>
        <translation>PERMUT(number,number_chosen)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_439</comment>
        <translation>is the value to test.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_474</comment>
        <translation>is the value to test.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_475</comment>
        <translation>is the value to test.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOTTABLE_GETPIVOTDATA_SUBTOTAL_PRODUCT</comment>
        <translation>Product</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOT_SUBTOTAL_PRODUCT</comment>
        <translation>Product</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SUBTOTAL_PRODUCT</comment>
        <translation>Product</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_BOTTOM_MARGIN</comment>
        <translation>Bottom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_009</comment>
        <translation>Bottom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_184</comment>
        <translation>is the real number you want to round down to an integer.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_185</comment>
        <translation>is the real number you want to round down to an integer.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_MERGESHEET_REPORT_Sheet</comment>
        <translation>Worksheet</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SOLVER_WORKSHEET</comment>
        <translation>Worksheet</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDataForm_NoValue</comment>
        <translation>This can&apos;t be applied to the selected range. Select a single cell in a range and try again.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDataForm_NotRange</comment>
        <translation>This can&apos;t be applied to the selected range. Select a single cell in a range and try again.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_553</comment>
        <translation>text1%1text2%1… are 1 to 253 text strings to be joined and can be text strings, numbers, or single-cell array references (e.g., a range of cells).</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_567</comment>
        <translation>text1%1text2%1... are 1 to 255 text strings to be joined into a single text string and can be text strings, numbers, or arrays of strings, such as a range of cells.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>NORMDOTINV_DESCRIPTION</comment>
        <translation>Returns the inverse of the normal cumulative distribution for the specified mean and standard deviation.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>NORMINV_DESCRIPTION</comment>
        <translation>Returns the inverse of the normal cumulative distribution for the specified mean and standard deviation.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sBadConfirmationPassword</comment>
        <translation>Confirmation password is not identical.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sConfirmError</comment>
        <translation>Confirmation password is not identical.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>STR_STYLE_20P_ACCENT_4</comment>
        <translation>20% - Accent4</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>STR_STYLE_40P_ACCENT_2</comment>
        <translation>40% - Accent2</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_293</comment>
        <translation>is the present value: the total amount that a series of future payments is worth now.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_320</comment>
        <translation>is the present value: the total amount that a series of future payments is worth now.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_077</comment>
        <translation>start_date and end_date are the two dates between which you want to know the number of days.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_458</comment>
        <translation>start_date and end_date are the two dates between which you want to know the number of days.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_570</comment>
        <translation>start_date and end_date are the two dates between which you want to know the number of days.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOTTABLE_GETPIVOTDATA_SUBTOTAL_STDEVP</comment>
        <translation>StdDevp</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PIVOT_SUBTOTAL_STDDEVP</comment>
        <translation>StdDevp</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SUBTOTAL_STDEVP</comment>
        <translation>StdDevp</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_074</comment>
        <translation>Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_075</comment>
        <translation>Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_076</comment>
        <translation>Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_255</comment>
        <translation>Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_352</comment>
        <translation>Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_423</comment>
        <translation>Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_Reg_Text</comment>
        <translation>Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_TextToConvert</comment>
        <translation>Text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_030</comment>
        <translation>is the probability of success on each trial.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_BINOMDISTRANGE_Probability_S</comment>
        <translation>is the probability of success on each trial</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_449</comment>
        <translation>is the number of characters to use.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_450</comment>
        <translation>is the number of characters to use.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_025</comment>
        <translation>Holidays</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_387</comment>
        <translation>Holidays</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>PopupFillSeries</comment>
        <translation>Series</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sNormal</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sStyleNormal</comment>
        <translation>Normal</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_CHECKSPELLING_FROMRIGHTFOOTER</comment>
        <translation>Right section </translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_CHECKSPELLING_FROMRIGHTHEADER</comment>
        <translation>Right section </translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_260</comment>
        <translation>Window_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_295</comment>
        <translation>Window_text</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_067</comment>
        <translation>is the probability of success on each trial, a number between 0 and 1 inclusive, containing 0 and 1</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_NEGBINOMDIST_Probability_S</comment>
        <translation>is the probability of success on each trial, a number between 0 and 1 inclusive.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_327</comment>
        <translation>Step</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_406</comment>
        <translation>Step</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_AutoFilter_Analysis_ColumnLabel</comment>
        <translation>Column</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_PivotTable_Consolidate_ColField</comment>
        <translation>Column</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_SortParam_KeyName_Column</comment>
        <translation>Column</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_TableDefaultColumnName</comment>
        <translation>Column</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_Undo_FormulaBarInsertFunction</comment>
        <translation>Insert Function</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_Undo_Function</comment>
        <translation>Insert Function</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDBE_RELATION</comment>
        <translation>Relation</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ETDBE_STR_RELATION</comment>
        <translation>Relation</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sBadZoomValue</comment>
        <translation>The number must be between 10 and 400. Try again by entering a number in this range.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>et_sErrorBadZoom</comment>
        <translation>The number must be between 10 and 400. Try again by entering a number in this range.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_121</comment>
        <translation>specifies the character at which to start the search. The default is 1</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_357</comment>
        <translation>specifies the character at which to start the search. The default is 1</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_349</comment>
        <translation>is the name of the ProgID of a registered COM automation add-in. Enclose the name in quotation marks.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaDesc_546</comment>
        <translation>is the name of the ProgID of a registered COM automation add-in. Enclose the name in quotation marks.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_AutoInput_Second</comment>
        <translation>Second</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_ParaInfo_064</comment>
        <translation>Second</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>STR_STYLE_20P_ACCENT_5</comment>
        <translation>20% - Accent5</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>STR_STYLE_40P_ACCENT_3</comment>
        <translation>40% - Accent3</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>STR_STYLE_60P_ACCENT_1</comment>
        <translation>60% - Accent1</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_CHECKSPELLING_FROMLEFTFOOTER</comment>
        <translation>Left section </translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>TX_CHECKSPELLING_FROMLEFTHEADER</comment>
        <translation>Left section </translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>SoundOrMovie</comment>
        <translation>From File</translation>
    </message>
</context>
</TS>
