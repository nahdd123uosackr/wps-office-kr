<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message>
        <source></source>
        <translation>실행 취소</translation>
    </message>
</context>
</TS>
