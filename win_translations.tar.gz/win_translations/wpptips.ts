<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message>
        <source></source>
        <translation>Evenly distribute the height of the selected row or the width of the column.</translation>
    </message>
</context>
</TS>
