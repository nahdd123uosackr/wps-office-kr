<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message>
        <source></source>
        <translation>Fade Left</translation>
    </message>
</context>
<context>
    <name>KxFormatGroupContent_Shadow</name>
    <message>
        <source>Enter 0% to 100% of value</source>
        <translation>Enter a value from 0% to 100%</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <translation>Enter a value from 1% to 200%</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>CHART_ChartTitle</comment>
        <translation>Chart Title</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>CHART_DEFAULTTEXT_CHARTTITLE</comment>
        <translation>Chart Title</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>HINT_CHARTTITLE</comment>
        <translation>Chart Title</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_EXPLOSION_2</comment>
        <translation>Explosion 2</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_EXPLOSION_2</comment>
        <translation>Explosion 2</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_IRREGULARSEAL2</comment>
        <translation>Explosion 2</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_SNIP_DIAGONAL_CORNER_RECTANGLE</comment>
        <translation>Diagonal Corners Snipped Rectangle</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_SNIP_DIAGONAL_CORNER_RECTANGLE</comment>
        <translation>Diagonal Corners Snipped Rectangle</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_ACTION_BUTTON_BACK_OR_PREVIOUS</comment>
        <translation>Action Button: Back or Previous</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_ACTION_BUTTON_BACK_OR_PREVIOUS</comment>
        <translation>Action Button: Go Back or Previous</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_ACTIONBUTTONBACKPREVIOUS</comment>
        <translation>Action Button: Back or Previous</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_DIAMOND</comment>
        <translation>Diamond</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_DIAMOND</comment>
        <translation>Diamond</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_DIAMOND</comment>
        <translation>Diamond</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_EXPLOSION_1</comment>
        <translation>Explosion 1</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_EXPLOSION_1</comment>
        <translation>Explosion 1</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_IRREGULARSEAL1</comment>
        <translation>Explosion 1</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_MULTIDOCUMENT</comment>
        <translation>Flowchart: Multidocument</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_FLOWCHART_MULTIDOCUMENT</comment>
        <translation>Flowchart: Multidocument</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTMULTIDOCUMENT</comment>
        <translation>Flowchart: Multidocument</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_DATA</comment>
        <translation>Flowchart: Data</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_FLOWCHART_DATA</comment>
        <translation>Flowchart: Data</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTINPUTOUTPUT</comment>
        <translation>Flowchart: Data</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_STRIPED_RIGHT_ARROW</comment>
        <translation>Striped Right Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_STRIPEDRIGHTARROW</comment>
        <translation>Striped Right Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_INSERT_SYMBOL</comment>
        <translation>Insert Symbol</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_SYMBOL</comment>
        <translation>Insert Symbol</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_CONNECTOR</comment>
        <translation>Flowchart: Connector</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_FLOWCHART_CONNECTOR</comment>
        <translation>Flowchart: Connector</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTCONNECTOR</comment>
        <translation>Flowchart: Connector</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_NOTCHED_RIGHT_ARROW</comment>
        <translation>Notched Right Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_NOTCHEDRIGHTARROW</comment>
        <translation>Notched Right Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_DIAGONAL_STRIPE</comment>
        <translation>Diagonal Stripe</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_DIAGONAL_STRIPE</comment>
        <translation>Diagonal Stripe</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_DIAGONALSTRIPE</comment>
        <translation>Diagonal Stripe</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>kso_BackupFile_Caption</comment>
        <translation>Backup Management</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>kso_BackupFile_DisplayName</comment>
        <translation>Backup Management</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_EXTRACT</comment>
        <translation>Flowchart: Extract</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_FLOWCHART_EXTRACT</comment>
        <translation>Flowchart: Extract</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTEXTRACT</comment>
        <translation>Flowchart: Extract</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_Desc_InsertMovie</comment>
        <translation>Insert Movie</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_DlgMovieTitle</comment>
        <translation>Insert Movie</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_CURVED_LEFT_ARROW</comment>
        <translation>Curved Left Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_CURVEDRIGHTARROW</comment>
        <translation>Curved Left Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_ROUND_DIAGONAL_CORNER_RECTANGLE</comment>
        <translation>Diagonal Corners Rounded Rectangle</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_ROUND_DIAGONAL_CORNER_RECTANGLE</comment>
        <translation>Diagonal Corners Rounded Rectangle</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_ACTION_BUTTON_DOCUMENT</comment>
        <translation>Action Button: Document</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_ACTION_BUTTON_DOCUMENT</comment>
        <translation>Action Button: Document</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_ACTIONBUTTONDOCUMENT</comment>
        <translation>Action Button: Document</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_LEFT_RIGHT_UP_ARROW</comment>
        <translation>Left-Right-Up Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_LEFTRIGHTUPARROW</comment>
        <translation>Left-Right-Up Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_TRAPEZOID</comment>
        <translation>Trapezoid</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_TEXTTURN_WARP_TRAPEZOID</comment>
        <translation>Fade Up</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_TRAPEZOID</comment>
        <translation>Trapezoid</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_TRAPEZOID</comment>
        <translation>Trapezoid</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_MULTIPLY</comment>
        <translation>Multiply</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_MULTIPLY</comment>
        <translation>Multiply</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>wpp_sTooltipMaterialTypeLegacyMatte</comment>
        <translation>Matte </translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>wpp_sTooltipMaterialTypeMatte</comment>
        <translation>Rough Bevel</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_COLORNAME_MSO_YELLOW</comment>
        <translation>Yellow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_COLORNAME_YELLOW</comment>
        <translation>Yellow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_LINE_CALLOUT_3</comment>
        <translation>Line Callout 3</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_LINE_CALLOUT_3</comment>
        <translation>Line Callout 3</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_BORDERCALLOUT2</comment>
        <translation>Line Callout 3</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_DECISION</comment>
        <translation>Flowchart: Decision</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_FLOWCHART_DECISION</comment>
        <translation>Flowchart: Decision</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTDECISION</comment>
        <translation>Flowchart: Decision</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_LINE_CALLOUT_2</comment>
        <translation>Line Callout 2</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_LINE_CALLOUT_2</comment>
        <translation>Line Callout 2</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_BORDERCALLOUT1</comment>
        <translation>Line Callout 2</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_SHAPE</comment>
        <translation>Shape</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_NOTCHEDCIRCULARARROW</comment>
        <translation>Shape</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>kso_NewWorkbook_Caption</comment>
        <translation>New Workbook</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>kso_NewWorkbook_DisplayName</comment>
        <translation>New Workbook</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_RIGHT_BRACE</comment>
        <translation>Right Brace</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_RIGHT_BRACE</comment>
        <translation>Right Brace</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_RIGHTBRACE</comment>
        <translation>Right Brace</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_LINE_ARROW_TYPE_ARROE</comment>
        <translation>Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_SHAPE_GROUPTYPE_ARROW</comment>
        <translation>Block Arrows</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_ARROW</comment>
        <translation>Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_LINE_CALLOUT_3_BORDER_AND_ACCENT_BAR</comment>
        <translation>Line Callout 3 (Border and Accent Bar)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_LINE_CALLOUT_3_BORDER_AND_ACCENT_BAR</comment>
        <translation>Line Callout 3 (Border and Accent Bar)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_ACCENTCALLOUT2</comment>
        <translation>Line Callout 3 (Border and Accent Bar)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_TEXTTURN_PATH_BUTTON</comment>
        <translation>Button</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_TEXTTURN_WARP_BUTTON</comment>
        <translation>Button</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_LINE_CALLOUT_3_NO_BORDER</comment>
        <translation>Line Callout 3 (No Border)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_LINE_CALLOUT_3_NO_BORDER</comment>
        <translation>Line Callout 3 (No Border)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_CALLOUT2</comment>
        <translation>Line Callout 3 (No Border)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_LINE_CALLOUT_2_BORDER_AND_ACCENT_BAR</comment>
        <translation>Line Callout 2 (Border and Accent Bar)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_LINE_CALLOUT_2_BORDER_AND_ACCENT_BAR</comment>
        <translation>Line Callout 2 (Border and Accent Bar)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_ACCENTCALLOUT1</comment>
        <translation>Line Callout 2 (Border and Accent Bar)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_DOWN_RIBBON</comment>
        <translation>Down Ribbon</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_RIBBON</comment>
        <translation>Down Ribbon</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_SEQUENTIAL_ACCESS_STORAGE</comment>
        <translation>Flowchart: Sequential Access Storage</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_FLOWCHART_SEQUENTIAL_ACCESS_STORAGE</comment>
        <translation>Flowchart: Sequential Access Storage</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTMAGNETICTAPE</comment>
        <translation>Flowchart: Sequential Access Storage</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_PROCESS</comment>
        <translation>Flowchart: Process</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_FLOWCHART_PROCESS</comment>
        <translation>Flowchart: Process</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTPROCESS</comment>
        <translation>Flowchart: Process</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_MOON</comment>
        <translation>Moon</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_MOON</comment>
        <translation>Moon</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_MOON</comment>
        <translation>Moon</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_LINE_CALLOUT_1</comment>
        <translation>Line Callout 1</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_LINE_CALLOUT_1</comment>
        <translation>Line Callout 1</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_BORDERCALLOUT90</comment>
        <translation>Line Callout 1</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_ACTION_BUTTON_SOUND</comment>
        <translation>Action Button: Sound</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_ACTION_BUTTON_SOUND</comment>
        <translation>Action Button: Sound</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_ACTIONBUTTONSOUND</comment>
        <translation>Action Button: Sound</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_LINE_CALLOUT_1_BORDER_AND_ACCENT_BAR</comment>
        <translation>Line Callout 1 (Border and Accent Bar)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_LINE_CALLOUT_1_BORDER_AND_ACCENT_BAR</comment>
        <translation>Line Callout 1 (Border and Accent Bar)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_ACCENTBORDERCALLOUT90</comment>
        <translation>Line Callout 1 (Border and Accent Bar)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_CURVED_UP_ARROW</comment>
        <translation>Curved Up Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_CURVEDDOWNARROW</comment>
        <translation>Curved Up Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_LINE_CALLOUT_1_NO_BORDER</comment>
        <translation>Line Callout 1 (No Border)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_LINE_CALLOUT_1_NO_BORDER</comment>
        <translation>Line Callout 1 (No Border)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_CALLOUT90</comment>
        <translation>Line Callout 1 (No Border)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_FillEffects</comment>
        <translation>Fill Effects</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_FillEffects</comment>
        <translation>Fill Effects</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_24_POINT_STAR</comment>
        <translation>24-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_24_POINT_STAR</comment>
        <translation>24-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_SEAL24</comment>
        <translation>24-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_16_POINT_STAR</comment>
        <translation>16-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_16_POINT_STAR</comment>
        <translation>16-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_SEAL16</comment>
        <translation>16-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_12_POINT_STAR</comment>
        <translation>12-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_12_POINT_STAR</comment>
        <translation>12-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_DOUBLE_WAVE</comment>
        <translation>Double Wave</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_DOUBLE_WAVE</comment>
        <translation>Double Wave</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_DOUBLEWAVE</comment>
        <translation>Double Wave</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_10_POINT_STAR</comment>
        <translation>10-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_10_POINT_STAR</comment>
        <translation>10-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_TERMINATOR</comment>
        <translation>Flowchart: Terminator</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_FLOWCHART_TERMINATOR</comment>
        <translation>Flowchart: Terminator</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTTERMINATOR</comment>
        <translation>Flowchart: Terminator</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_BringForward</comment>
        <translation>Bring Forward</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_Order_BringForward</comment>
        <translation>Bring Forward</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_32_POINT_STAR</comment>
        <translation>32-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_32_POINT_STAR</comment>
        <translation>32-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_SEAL32</comment>
        <translation>32-Point Star</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>OMATH_SYMBOL_CATEGORY_ARROWS</comment>
        <translation>Arrows</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>OMATH_SYMBOL_CA_ARROWS</comment>
        <translation>Arrows</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_LineStylePalette</comment>
        <translation>Line Style</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_LineStyle</comment>
        <translation>Line Style</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_FillColor</comment>
        <translation>Fill Color</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_FillColor</comment>
        <translation>Fill Color</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>CHART_ChangeFormatting</comment>
        <translation>Change Formatting</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>CHART_DELETE_DRAWING_AREA</comment>
        <translation>Change Formatting</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>_kso_Generic_MessageBox_Caption</comment>
        <translation>WPS Office</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>_kso_ksoProductName</comment>
        <translation>WPS Office</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_PREDEFINED_PROCESS</comment>
        <translation>Flowchart: Predefined Process</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_FLOWCHART_PREDEFINED_PROCESS</comment>
        <translation>Flowchart: Predefined Process</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTPREDEFINEDPROCESS</comment>
        <translation>Flowchart: Predefined Process</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_DISPLAY</comment>
        <translation>Flowchart: Display</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_FLOWCHART_DISPLAY</comment>
        <translation>Flowchart: Display</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTDISPLAY</comment>
        <translation>Flowchart: Display</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_SNIP_SAME_SIDE_CORNER_RECTANGLE</comment>
        <translation>Top Corners Snipped Rectangle</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_SNIP_SAME_SIDE_CORNER_RECTANGLE</comment>
        <translation>Top Corners Snipped Rectangle</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>kso_sEtInsertAsIcon</comment>
        <translation>Insert an icon that represents the contents of the file into your document.</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>kso_sWpsInsertAsIcon</comment>
        <translation>Insert an icon that represents the contents of the file into your document.</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_3D_FROAMT_BELVEL_HardEdge</comment>
        <translation>Hard Edge</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_3D_FROAMT_MATERIAL_HARDEDGE</comment>
        <translation>Dark Edge</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_Cmd_SaveAsMovieFailureCaption</comment>
        <translation>Error</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_Cmd_SaveAsPictureFailureCaption</comment>
        <translation>Error</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>kso_sActivePartOf</comment>
        <translation>Part of %s</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>kso_sPartOf</comment>
        <translation>Part of %s</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_OFF_PAGE_CONNECTOR</comment>
        <translation>Flowchart: Off-page Connector</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTOFFPAGECONNECTOR</comment>
        <translation>Flowchart: Off-page Connector</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_3DTiltDown</comment>
        <translation>Rotate 3-D</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_3DTiltLeft</comment>
        <translation>Rotate 3-D</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_3DTiltRight</comment>
        <translation>Rotate 3-D</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_3DTiltUp</comment>
        <translation>Rotate 3-D</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_PENTAGON</comment>
        <translation>Pentagon</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_HOMEPLATE</comment>
        <translation>Pentagon</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_CIRCULAR_ARROW</comment>
        <translation>Circular Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_CIRCULARARROW</comment>
        <translation>Circular Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_NudgeDown</comment>
        <translation>Nudge Object</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_NudgeLeft</comment>
        <translation>Nudge Object</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_NudgeRight</comment>
        <translation>Nudge Object</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_NudgeUp</comment>
        <translation>Nudge Object</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_FLOWCHART_DOCUMENT</comment>
        <translation>Flowchart: Document</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_FLOWCHART_DOCUMENT</comment>
        <translation>Flowchart: Document</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_FLOWCHARTDOCUMENT</comment>
        <translation>Flowchart: Document</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_SHAPE_GROUPTYPE_LINE</comment>
        <translation>Lines</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_LINE</comment>
        <translation>Lines</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_LINE</comment>
        <translation>Lines</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_3D_FROAMT_LIGHTING_PLANE</comment>
        <translation>Flat</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_3D_FROAMT_MATERIAL_PLANE</comment>
        <translation>Flat</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_LEFT_RIGHT_ARROW</comment>
        <translation>Left-Right Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_LEFTRIGHTARROW</comment>
        <translation>Left-Right Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_LEFT_BRACE</comment>
        <translation>Left Brace</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2_TOOLTIP_LEFT_BRACE</comment>
        <translation>Left Brace</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_LEFTBRACE</comment>
        <translation>Left Brace</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>_kso_SaveDiagTitle</comment>
        <translation>Save As</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>_kso_SaveToFileDialogName</comment>
        <translation>Save As</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>_KsoFileFormatDesc_MSWORD8_File</comment>
        <translation>Word 97-2003 Documents </translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>_KsoLinuxOleDocFile</comment>
        <translation>Microsoft Word 97-2003 Document (*.doc)</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_CropPicture</comment>
        <translation>Crop</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_PictureCrop</comment>
        <translation>Crop</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_Custom</comment>
        <translation>Custom</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DgUil_KSO_Cmd_WordArtCharacterSpacingCustom</comment>
        <translation>Custom</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWING2STR_CURVED_DOWN_ARROW</comment>
        <translation>Curved Down Arrow</translation>
    </message>
    <message>
        <source>Enter 1% to 200% of value</source>
        <comment>DRAWINGSTR_CURVEDUPARROW</comment>
        <translation>Curved Down Arrow</translation>
    </message>
</context>
</TS>
