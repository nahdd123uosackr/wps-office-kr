<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message>
        <source></source>
        <translation>AI 교차 참조를 사용하려면 최소 %n페이지가 필요합니다</translation>
    </message>
</context>
</TS>
