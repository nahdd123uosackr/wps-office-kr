<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message>
        <source></source>
        <translation>Edit Connection Properties</translation>
    </message>
    <message>
        <source>CmpSideBySide.content</source>
        <translation>Instead of switching back and forth between documents, view them side by side. It makes comparing them easier.</translation>
    </message>
    <message>
        <source>SmartTableExtraction.content</source>
        <translation>AI extract as editable table</translation>
    </message>
    <message>
        <source>CmpSideBySide.title</source>
        <translation>View Side by Side.</translation>
    </message>
    <message>
        <source>SmartTableExtraction.title</source>
        <translation>Smart Table Extraction</translation>
    </message>
</context>
</TS>
