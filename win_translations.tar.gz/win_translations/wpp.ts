<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name></name>
    <message>
        <source></source>
        <translation>More Colors</translation>
    </message>
</context>
<context>
    <name>CTableStyle</name>
    <message>
        <source>Dark Style 2-Emphasize 3/Emphasize 4</source>
        <translation>Dark Style 2-Emphasize 3/Emphasize 4</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <translation>Dark Style 2-Emphasize 5/Emphasize 6</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextZip</comment>
        <translation>Magnify</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextZip</comment>
        <translation>Magnify</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>shortHint</comment>
        <translation>Note</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextSpinner</comment>
        <translation>Spinner</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextSpinner</comment>
        <translation>Spinner</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_TEXT_OF_CENTERTITLE_IN_MASTER</comment>
        <translation>Click to edit Master title style</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_TEXT_OF_TITLE_IN_MASTER</comment>
        <translation>Click to edit Master title style</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_TP_ANIMATIONSCHEMECATEGORY1</comment>
        <translation>Recently Used</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_TP_DESIGNCATEGORY2</comment>
        <translation>Recently Used</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>OMath</comment>
        <translation>Left</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_SB_VIEW_SLIDELAYOUT</comment>
        <translation>Slide Layout</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_SETLAYOUT</comment>
        <translation>Slide Layout</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextFadedSwivel</comment>
        <translation>Swivel</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextFadedSwivel</comment>
        <translation>Swivel</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextDescend</comment>
        <translation>Descend</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextAscend</comment>
        <translation>Descend</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEffectPathDiamond</comment>
        <translation>Diamond</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextDiamond</comment>
        <translation>Diamond</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextDiamond</comment>
        <translation>Diamond</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Personal Version</comment>
        <translation>Switch UI</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Professional Version</comment>
        <translation>Switch UI</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_LAYOUT_TITLE</comment>
        <translation>Title Slide</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_TITLE_SLIDE_LAYOUT_NAME</comment>
        <translation>Title Slide</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextCredits</comment>
        <translation>Credits</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextCredits</comment>
        <translation>Credits</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextCustom</comment>
        <translation>Custom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextShimmer</comment>
        <translation>Custom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextCustom</comment>
        <translation>Custom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextShimmer</comment>
        <translation>Custom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sSlideSizeCustom</comment>
        <translation>Custom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sActionVerbPlayText</comment>
        <translation>Play</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEffectMediaPlay</comment>
        <translation>Play</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sCaptionPlay</comment>
        <translation>Play</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_CustomAnimation_Caption</comment>
        <translation>Custom Animation</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_CustomAnimation_DisplayName</comment>
        <translation>Custom Animation</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Menu</comment>
        <translation>AI Matting</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextAscend</comment>
        <translation>Ascend</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextDescend</comment>
        <translation>Ascend</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextRandomBars</comment>
        <translation>Random Bars</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextRandomBars</comment>
        <translation>Random Bars</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextStrips</comment>
        <translation>Strips</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextStrips</comment>
        <translation>Strips</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextGrowAndTurn</comment>
        <translation>Grow &amp; Turn</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextGrowAndTurn</comment>
        <translation>Shrink &amp; Turn</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_NewBlankFileCaption</comment>
        <translation>New Blank Presentation</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_NewBlankFileHint</comment>
        <translation>New Blank Presentation</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextBox</comment>
        <translation>Box</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextBox</comment>
        <translation>Box</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextSwish</comment>
        <translation>Swish</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextSwish</comment>
        <translation>Swish</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextFadedZoom</comment>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextFadedZoom</comment>
        <translation>Zoom</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextBlinds</comment>
        <translation>Blinds</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextBlinds</comment>
        <translation>Blinds</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextThinLine</comment>
        <translation>Thread</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextThinLine</comment>
        <translation>Thread</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WpNOTESMASTERLAYOUT</comment>
        <translation>Notes Master Layout</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WpNOTESMASTERLAYOUT_CAPTION</comment>
        <translation>Notes Master Layout</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextUnfold</comment>
        <translation>Unfold</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextUnfold</comment>
        <translation>Unfold</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextSling</comment>
        <translation>Sling</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextSling</comment>
        <translation>Sling</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sNotMatchPassword</comment>
        <translation>The password confirmation does not match.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sNotMatchPermissionPassword</comment>
        <translation>The password confirmation does not match.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sChinese</comment>
        <translation>Chinese(PRC)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sCountryLanguage</comment>
        <translation>Chinese(PRC)</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextLightSpeed</comment>
        <translation>Light Speed</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextLightSpeed</comment>
        <translation>Light Speed</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WpDRAGDESIGN</comment>
        <translation>Drag-and-Drop</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WpDRAGSLIDE</comment>
        <translation>Drag-and-Drop</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_ANIMATIONTYPE_APPEARANDDIM_TIP</comment>
        <translation>Body: Appear</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_ANIMATIONTYPE_APPEAR_TIP</comment>
        <translation>Body: Appear</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_TBLSTYLE_TT17</comment>
        <translation>Light Style 1 - Accent 2</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextFade</comment>
        <translation>Fade</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextFade</comment>
        <translation>Fade</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextWipe</comment>
        <translation>Wipe</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextWipe</comment>
        <translation>Wipe</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEffectPathWave</comment>
        <translation>Wave</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEffectWave</comment>
        <translation>Wave</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Linux Version</comment>
        <translation>WPS Customer Service</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>Windows Version</comment>
        <translation>WPS Customer Service</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextWedge</comment>
        <translation>Wedge</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextWedge</comment>
        <translation>Wedge</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_NewFileFromForbiddenCityTemplatesCaption</comment>
        <translation>Create from Forbidden City Templates</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_NewFileFromForbiddenCityTemplatesHint</comment>
        <translation>Create from Forbidden City Templates</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextGlide</comment>
        <translation>Glide</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextGlide</comment>
        <translation>Glide</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sClose</comment>
        <translation>Close</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sCloseDialog</comment>
        <translation>Close</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>AEO_MEDIA_PLAYMODE</comment>
        <translation>Play</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>AEO_MEDIA_VOL</comment>
        <translation>Volume</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>AEO_VIDEO_FULLSCREEN</comment>
        <translation>Play Full Screen</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>AEO_VIDEO_LOOP</comment>
        <translation>Loop until Stopped</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>AEO_VIDEO_REWIND</comment>
        <translation>Rewind after Playing</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_FIND_NOTFOUND</comment>
        <translation>Searching to the whole file is completed, and no search item was found.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_REPLACEALL_NOTFOUND</comment>
        <translation>Searching to the whole file is completed, and no search item was found.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_REPLACE_NOTFOUND</comment>
        <translation>Searching to the whole file is completed, and no search item was found.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WpNOTESLAYOUT</comment>
        <translation>Notes Layout</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WpNOTESLAYOUT_CAPTION</comment>
        <translation>Notes Layout</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextFold</comment>
        <translation>Collapse</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextFold</comment>
        <translation>Collapse</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_TableStyleCaption</comment>
        <translation>Table Style</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_TableStyleDisplayName</comment>
        <translation>Table Style</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_ANIMATIONTYPE_NONE</comment>
        <translation>No Animation</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_ANIMATIONTYPE_NONE_TIP</comment>
        <translation>No Animation</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_TP_ANIMATIONSCHEMECATEGORY2</comment>
        <translation>No Animation</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextSplit</comment>
        <translation>Split</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextSplit</comment>
        <translation>Split</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextFloat</comment>
        <translation>Float</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextFloat</comment>
        <translation>Float</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_DEFAULT_DESIGN</comment>
        <translation>Default Design</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WpDefaultDesign</comment>
        <translation>Default Design</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_SlideTransition_Caption</comment>
        <translation>Slide Transition</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_SlideTransition_DisplayName</comment>
        <translation>Slide Transition</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>DgDesc_ClearTextBox</comment>
        <translation>Clear</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WpCLEAR</comment>
        <translation>Clear</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_FIND_FINISH</comment>
        <translation>Searching to the whole file is completed.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WP_REPLACE_FINISH</comment>
        <translation>Searching to the whole file is completed.</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEffectPathPlus</comment>
        <translation>Plus</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextPlus</comment>
        <translation>Plus</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextPlus</comment>
        <translation>Plus</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WpPrintWays_SpeakerNotes</comment>
        <translation>Notes Pages</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>WpSPEAKERNOTES</comment>
        <translation>Speaker Notes</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sBasicEffect</comment>
        <translation>Basic</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sPathBasicEffect</comment>
        <translation>Basic</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_SlideLayout_Caption</comment>
        <translation>Slide Layout</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_SlideLayout_DisplayName</comment>
        <translation>Slide Layout</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextRandomEffects</comment>
        <translation>Random Effects</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextRandomEffects</comment>
        <translation>Random Effects</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sChangeEffect</comment>
        <translation>Change</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sModifyOperation</comment>
        <translation>Change</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextBounce</comment>
        <translation>Bounce</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextBounce</comment>
        <translation>Bounce</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextCenterRevolve</comment>
        <translation>Center Revolve</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextCEnterRevolve</comment>
        <translation>Center Revolve</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEffectPathCircle</comment>
        <translation>Circle</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextCircle</comment>
        <translation>Circle</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextCircle</comment>
        <translation>Circle</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimEnterEffectTextBoomerang</comment>
        <translation>Boomerang</translation>
    </message>
    <message>
        <source>Dark Style 2-Emphasize 5/Emphasize 6</source>
        <comment>wpp_sAnimExitEffectTextBoomerang</comment>
        <translation>Boomerang</translation>
    </message>
</context>
</TS>
